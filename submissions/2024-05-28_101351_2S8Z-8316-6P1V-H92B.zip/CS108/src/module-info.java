module ChaCuN {
    requires javafx.controls;
    requires java.net.http;
    requires jdk.unsupported.desktop;

    exports ch.epfl.chacun;
    exports ch.epfl.chacun.gui;
}