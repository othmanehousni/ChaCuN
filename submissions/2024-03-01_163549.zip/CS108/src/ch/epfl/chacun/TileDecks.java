package ch.epfl.chacun;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 *
 * @author Othmane HOUSNI (375072)
 * @author Hamza Zoubayri (361522)
 *
 * Represents the decks of tiles of three different kinds: start, normal, and menhir.
 * It allows treating all tiles uniformly and simplifies the handling of tiles throughout the game.
 */
final public record TileDecks(List<Tile> startTiles, List<Tile> normalTiles, List<Tile> menhirTiles) {

    /**
     * Ensures the immutability of TileDecks by copying the input lists.
     */
    public TileDecks{
        startTiles = List.copyOf(startTiles);
        normalTiles = List.copyOf(normalTiles);
        menhirTiles = List.copyOf(menhirTiles);
    }

    /**
     * Returns the number of tiles available in the deck of the specified kind.
     *
     * @param kind The kind of tiles to count.
     * @return The number of available tiles in the specified deck.
     */
    public  int deckSize(Tile.Kind kind){
        return switch (kind){
            case START -> startTiles.size();
            case NORMAL -> normalTiles.size();
            case MENHIR -> menhirTiles.size();
        };
    }

    /**
     * Returns the top tile from the deck of the specified kind, or null if the deck is empty.
     *
     * @param kind The kind of the deck from which to retrieve the top tile.
     * @return The top tile of the specified deck, or null if the deck is empty.
     */
    public Tile topTile(Tile.Kind kind){

        return switch (kind){
            case START -> startTiles.isEmpty() ? null : startTiles.getFirst();
            case NORMAL -> normalTiles.isEmpty() ? null : normalTiles.getFirst();
            case MENHIR -> menhirTiles.isEmpty() ? null : menhirTiles.getFirst();
        };
    }

    /**
     * Returns a new TileDecks instance with the top tile of the specified kind removed.
     *
     * @param kind The kind of tile deck from which to remove the top tile.
     * @return A new TileDecks instance with the top tile removed.
     * @throws IllegalArgumentException If the specified deck is empty.
     */
    public TileDecks withTopTileDrawn(Tile.Kind kind){
        ArrayList <Tile> startTilesToArrayList = new ArrayList<>(startTiles);
        ArrayList <Tile> normalTilesToArrayList = new ArrayList<>(normalTiles);
        ArrayList<Tile> menhirTilesToArrayList = new ArrayList<>(menhirTiles);

        if (kind == Tile.Kind.START && !startTilesToArrayList.isEmpty()){
            startTilesToArrayList.removeFirst();
        }else if (kind == Tile.Kind.NORMAL && !normalTilesToArrayList.isEmpty()){
            normalTilesToArrayList.removeFirst();
        }else if (kind == Tile.Kind.MENHIR && !menhirTilesToArrayList.isEmpty()){
            menhirTilesToArrayList.removeFirst();}
        else {
            throw new IllegalArgumentException();
        }

        return new TileDecks(startTilesToArrayList,normalTilesToArrayList,menhirTilesToArrayList);
    }

    /**
     * Returns a new TileDecks instance with the top tiles removed until a tile satisfies the given predicate.
     *
     * @param kind The kind of tile deck from which to remove the top tiles.
     * @param predicate A predicate that determines which tiles to remove.
     * @return A new TileDecks instance with the top tiles removed as per the predicate.
     */
    public TileDecks withTopTileDrawnUntil(Tile.Kind kind, Predicate<Tile> predicate){

        TileDecks tileDeck = this;
        while (tileDeck.topTile(kind) !=null && !predicate.test(tileDeck.topTile(kind))) {
                tileDeck = withTopTileDrawn(kind);
            }
            return tileDeck;
        }

    }